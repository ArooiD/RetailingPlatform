package ru.mirea.shops;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopsApplicationTests {

    @Test
    void contextLoads() {
    }

}
